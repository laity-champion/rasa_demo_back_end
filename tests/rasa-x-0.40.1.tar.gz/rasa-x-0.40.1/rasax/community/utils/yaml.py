import os
import re
from collections import OrderedDict
from pathlib import Path
from typing import Any, Dict, List, Optional, Text, TextIO, Union
import ruamel.yaml as yaml
from ruamel.yaml.comments import CommentedMap

from rasa.shared.exceptions import RasaException

import rasax.community.utils.io as io_utils

YAML_VERSION = (1, 2)


def _fix_yaml_loader() -> None:
    """Ensure that any string read by yaml is represented as unicode."""

    def construct_yaml_str(self, node):
        # Override the default string handling function
        # to always return unicode objects
        return self.construct_scalar(node)

    yaml.Loader.add_constructor("tag:yaml.org,2002:str", construct_yaml_str)
    yaml.SafeLoader.add_constructor("tag:yaml.org,2002:str", construct_yaml_str)


def _replace_yaml_environment_variables() -> None:
    """Enable yaml loader to process the environment variables in the yaml."""

    # eg. ${USER_NAME}, ${PASSWORD}
    env_var_pattern = re.compile(r"^(.*)\$\{(.*)\}(.*)$")
    yaml.add_implicit_resolver("!env_var", env_var_pattern)

    def env_var_constructor(loader, node):
        """Process environment variables found in the YAML."""
        value = loader.construct_scalar(node)
        expanded_vars = os.path.expandvars(value)
        if "$" in expanded_vars:
            not_expanded = [w for w in expanded_vars.split() if "$" in w]
            raise RasaException(
                "Error when trying to expand the environment variables"
                " in '{}'. Please make sure to also set these environment"
                " variables: '{}'.".format(value, not_expanded)
            )
        return expanded_vars

    yaml.SafeConstructor.add_constructor("!env_var", env_var_constructor)


def _is_ascii(text: Text) -> bool:
    return all(ord(character) < 128 for character in text)


def _enable_ordered_dict_yaml_dumping() -> None:
    """Ensure that `OrderedDict`s are dumped so that the order of keys is respected."""

    def _order_rep(dumper: yaml.Representer, _data: Dict[Any, Any]) -> Any:
        return dumper.represent_mapping(
            "tag:yaml.org,2002:map", _data.items(), flow_style=False
        )

    yaml.add_representer(OrderedDict, _order_rep)


def _convert_to_ordered_dict(obj: Any) -> Any:
    """Convert object to an `OrderedDict`.

    Args:
        obj: Object to convert.

    Returns:
        An `OrderedDict` with all nested dictionaries converted if `obj` is a
        dictionary, otherwise the object itself.
    """
    # use recursion on lists
    if isinstance(obj, list):
        return [_convert_to_ordered_dict(element) for element in obj]

    if isinstance(obj, dict):
        out = OrderedDict()
        # use recursion on dictionaries
        for k, v in obj.items():
            out[k] = _convert_to_ordered_dict(v)

        return out

    # return all other objects
    return obj


def load_yaml(content: Union[str, TextIO]) -> Any:
    """Load content from yaml."""
    return yaml.round_trip_load(content)


def read_yaml(content: Text) -> Union[List[Any], Dict[Text, Any]]:
    """Parses yaml from a text.

     Args:
        content: A text containing yaml content.
    """
    _fix_yaml_loader()

    _replace_yaml_environment_variables()

    yaml_parser = yaml.YAML(typ="safe")
    yaml_parser.version = YAML_VERSION

    if _is_ascii(content):
        # Required to make sure emojis are correctly parsed
        content = (
            content.encode("utf-8")
            .decode("raw_unicode_escape")
            .encode("utf-16", "surrogatepass")
            .decode("utf-16")
        )

    return yaml_parser.load(content) or {}


def read_yaml_file(filename: Text) -> Union[List[Any], Dict[Text, Any]]:
    """Parses a yaml file.

     Args:
        filename: The path to the file which should be read.
    """
    return read_yaml(io_utils.read_file(filename, io_utils.DEFAULT_ENCODING))


def write_yaml_file(
    data: Any, filename: Union[Text, Path], should_preserve_key_order: bool = False
) -> None:
    """Writes a yaml file.

    Args:
        data: The data to write.
        filename: The path to the file which should be written.
        should_preserve_key_order: Whether to preserve key order in `data`.
    """
    if should_preserve_key_order:
        _enable_ordered_dict_yaml_dumping()
        data = _convert_to_ordered_dict(data)

    with Path(filename).open("w", encoding=io_utils.DEFAULT_ENCODING) as outfile:
        yaml.dump(data, outfile, default_flow_style=False, allow_unicode=True)


def dump_yaml(content: Any) -> Optional[Text]:
    """Represent an object as a YAML-formatted string.

    Args:
        content: Object to convert to YAML.

    Returns:
        Object represented as YAML.
    """
    _content = CommentedMap(content)
    return yaml.round_trip_dump(_content, default_flow_style=False)


def dump_as_yaml_to_temporary_file(data: Dict) -> Optional[Text]:
    """Dump `data` as yaml to a temporary file."""

    content = dump_yaml(data)
    return io_utils.create_temporary_file(content)


# unlike rasa.utils.io's yaml writing method, this one
# uses round_trip_dump() which preserves key order and doesn't print yaml markers
def dump_yaml_to_file(filename: Union[Text, Path], content: Any) -> None:
    """Dump content to yaml."""
    io_utils.write_file(filename, dump_yaml(content))


def extract_partial_endpoint_config(
    endpoint_config_path: Union[Text, Path], key: Text
) -> Optional[Dict]:
    """Extracts partial endpoint config at `key`.

    `endpoints.yml` can contain sections that are not used within Rasa X.
    E.g. `models` section belongs only to Rasa Open Source, and contains some
    environment variables that don't exist in Rasa X containers. That's the reason
    why we first need to read yaml file without expanding the variables.

    Args:
        endpoint_config_path: Path to endpoint config file to read.
        key: Endpoint config key (section) to extract.

    Returns:
        Endpoint config initialised only from `key`.
    """
    import rasax.community.utils.cli

    try:
        endpoint_file = io_utils.read_file(endpoint_config_path)
        # read yaml file not expanding the environment variables
        endpoint_dict = load_yaml(endpoint_file)

        # `endpoint_dict` will be `None` if the file was empty or purely
        # composed of comments.
        if endpoint_dict is None:
            return None

        # Dump to YAML again, but selecting only the section we're interested
        # in.
        endpoint_yaml = dump_yaml({key: endpoint_dict.get(key)})

        # Read yaml string and try to expand the environment variables.
        endpoint_dict = read_yaml(endpoint_yaml)
        if isinstance(endpoint_dict, dict) and key in endpoint_dict:
            return endpoint_dict[key]
    except ValueError as e:
        rasax.community.utils.cli.raise_warning(
            f"Error reading endpoints file at path '{endpoint_config_path}':\n{e}."
        )
    except Exception as e:
        rasax.community.utils.cli.raise_warning(
            f"Encountered unexpected error reading endpoint config "
            f"file at path {endpoint_config_path}:\n{e}"
        )

    return None
