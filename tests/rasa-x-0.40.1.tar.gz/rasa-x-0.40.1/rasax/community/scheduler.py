import logging
import multiprocessing
from multiprocessing.context import BaseContext
from typing import Text, Union, Dict, Optional, TYPE_CHECKING, Set, Any, List, Callable
from datetime import datetime, timedelta

from apscheduler.job import Job
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger
from pytz import UnknownTimeZoneError, utc

import rasax.community.database.utils
import rasax.community.utils.common as common_utils
import rasax.community.config as rasa_x_config
from rasax.community.services import background_dump_service
from rasax.community.services.background_dump_service import DumpService
from rasax.community.services.insights import insight_service

if TYPE_CHECKING:
    from multiprocessing import Process, Queue

logger = logging.getLogger(__name__)

JOB_ID_KEY = "job_id"
CANCEL_JOB_KEY = "cancel"
JOB_SCHEDULE_KEY = "schedule"

_job_queue: Optional[multiprocessing.Queue] = None


def initialize_global_state(context: BaseContext) -> None:
    """Initialize the global state of the module.

    Args:
        context: The current multiprocessing context.
    """
    global _job_queue
    _job_queue = context.Queue()


def get_jobs_queue() -> Optional["Queue"]:
    """Return the background scheduler's job queue.

    Returns:
        Job queue.
    """
    return _job_queue


def set_jobs_queue(queue: "Queue") -> None:
    """Set the background scheduler's job queue. Use `utils.run_in_process` to
    create new processes that will inherit this queue.

    Args:
        queue: Multiprocessing Queue object to use as queue.
    """
    global _job_queue
    _job_queue = queue


def _run_scheduler() -> None:
    try:
        logging.getLogger("apscheduler.scheduler").setLevel(logging.WARNING)
        common_utils.update_log_level()
        scheduler = BackgroundScheduler()
        scheduler.start()
    except UnknownTimeZoneError:
        logger.warning(
            "apscheduler could not find a timezone and is "
            "defaulting to utc. This is probably because "
            "your system timezone is not set. "
            'Set it with e.g. echo "Europe/Berlin" > '
            "/etc/timezone"
        )
        scheduler = BackgroundScheduler(timezone=utc)
        scheduler.start()

    _schedule_background_jobs(scheduler)

    # Check regularly if a job should be executed right away
    try:
        while True:
            job_information = _job_queue.get()
            _handle_next_queue_item(scheduler, job_information)
    except KeyboardInterrupt:
        # Handle Ctrl-C in local mode
        pass


def _schedule_background_jobs(scheduler: BackgroundScheduler) -> None:
    for scheduling_fn in _jobs().values():
        scheduling_fn(scheduler, None)


def _jobs() -> Dict[Text, Callable[[BackgroundScheduler, Optional[Dict]], None]]:
    return {
        "telemetry": _schedule_telemetry,
        background_dump_service.BACKGROUND_DUMPING_JOB_ID: _schedule_file_dumping,
        **_server_mode_only_jobs(),
        **_git_synchronization_job(),
    }


def _server_mode_only_jobs() -> Dict[
    Text, Callable[[BackgroundScheduler, Optional[Dict]], None]
]:
    if rasa_x_config.LOCAL_MODE:
        return {}

    return {
        insight_service.CROSS_VAL_BACKGROUND_JOB_ID: _schedule_cross_validation,
        "analytics": _schedule_analytics_caching,
    }


def _git_synchronization_job() -> Dict[
    Text, Callable[[BackgroundScheduler, Optional[Dict]], None]
]:
    # Git might be not available locally so we have to check before importing it as
    # this might otherwise lead to an error (Integrated Version Control can be used
    # used locally using the `GIT_DEVELOPMENT_MODE`).
    if common_utils.is_git_available():
        from rasax.community.services.integrated_version_control import git_service

        return {git_service.GIT_BACKGROUND_JOB_ID: _schedule_git_synchronization}

    return {}


def _schedule_git_synchronization(
    scheduler: BackgroundScheduler, _: Optional[Dict] = None
) -> None:
    from rasax.community.services.integrated_version_control import git_service

    logger.debug("Scheduled Git synchronization.")
    scheduler.add_job(
        git_service.run_background_synchronization,
        "cron",
        id=git_service.GIT_BACKGROUND_JOB_ID,
        next_run_time=datetime.now(),
        replace_existing=True,
        minute="*",
    )


def _schedule_telemetry(
    scheduler: BackgroundScheduler, _: Optional[Dict] = None
) -> None:
    from rasax.community import telemetry

    logger.debug("Scheduled telemetry.")
    scheduler.add_job(
        telemetry.track_project_status,
        "interval",
        seconds=rasa_x_config.telemetry_status_event_interval,
    )


def _schedule_analytics_caching(
    scheduler: BackgroundScheduler, _: Optional[Dict] = None
) -> None:
    if common_utils.is_enterprise_installed():
        from rasax.community.services.analytics_service import AnalyticsService

        logger.debug("Scheduled analytics caching.")
        scheduler.add_job(
            AnalyticsService.run_analytics_caching,
            "cron",
            replace_existing=True,
            **rasa_x_config.analytics_update_kwargs,
        )


def _schedule_cross_validation(
    scheduler: BackgroundScheduler, _: Optional[Dict] = None
) -> None:
    with rasax.community.database.utils.session_scope() as session:
        insights_service = insight_service.InsightService(session)
        schedule = insights_service.get_cross_validation_schedule()

    if schedule is None:
        # Cross-validation runs are paused
        return

    logger.debug("Scheduled intent insight calculation.")
    trigger = CronTrigger.from_crontab(schedule)
    scheduler.add_job(
        insight_service.InsightService.run_scheduled_calculation,
        id=insight_service.CROSS_VAL_BACKGROUND_JOB_ID,
        replace_existing=True,
        trigger=trigger,
    )


def _schedule_file_dumping(
    scheduler: BackgroundScheduler,
    job_information: Optional[Dict[Text, Union[bool, Dict, Set]]],
) -> None:
    if job_information is None:
        return

    dumping_delay = datetime.now() + timedelta(
        seconds=rasa_x_config.MAX_DUMPING_DELAY_IN_SECONDS
    )

    logger.debug("Scheduled file dumping.")
    scheduler.add_job(
        DumpService.dump_changes,
        "date",
        run_date=dumping_delay,
        id=background_dump_service.BACKGROUND_DUMPING_JOB_ID,
        kwargs=job_information,
    )


def _handle_next_queue_item(
    scheduler: BackgroundScheduler, job_information: Dict[Text, Any]
) -> None:
    job_id = job_information.pop(JOB_ID_KEY)
    existing_job: Optional[Job] = scheduler.get_job(job_id)

    should_cancel_job = job_information.pop(CANCEL_JOB_KEY, False)
    if should_cancel_job and existing_job:
        logger.debug(f"Canceling job with ID '{job_id}'.")
        scheduler.remove_job(job_id)
        return

    if existing_job:
        _modify_job(existing_job, job_information)
        return

    registered_scheduling_fn = _jobs().get(job_id)
    if not registered_scheduling_fn:
        logger.warning(f"Did not find a scheduled job with ID '{job_id}'.")
        return

    registered_scheduling_fn(scheduler, job_information)


def _modify_job(
    background_job: Job, job_modification: Dict[Text, Union[bool, Dict, Set]]
) -> None:
    changes = {}
    job_id = background_job.id

    run_immediately = job_modification.pop("run_immediately", False)
    if run_immediately:
        changes["next_run_time"] = datetime.now()
        logger.debug(f"Running job with id '{job_id}' immediately.")

    if JOB_SCHEDULE_KEY in job_modification:
        _reschedule(background_job, job_modification.pop(JOB_SCHEDULE_KEY))

    # Set keyword arguments to call scheduled job function with
    changes["kwargs"] = _get_merged_job_kwargs(background_job, job_modification)

    background_job.modify(**changes)
    logger.debug(f"Modifying job with id '{background_job.id}'.")


def _reschedule(background_job: Job, new_schedule: Any) -> None:
    if not isinstance(new_schedule, str):
        logger.error("New schedule needs to be a crontab as string.")
        return

    try:
        background_job.reschedule(CronTrigger.from_crontab(new_schedule))
        logger.debug(f"Updated schedule for job '{background_job}'.")
    except ValueError as e:
        logger.error(f"The provided cron schedule '{new_schedule} is invalid: {e}")


def _get_merged_job_kwargs(
    existing_job: Job, new_job_kwargs: Dict[Text, Union[bool, Dict, Set]]
) -> Dict:
    """Merge `kwargs` for the existing background job with new values.

    `kwargs` are the arguments which are passed as argument to the scheduled function
    which the `BackgroundScheduler` executes. Re-scheduling an existing job should not
    overwrite these values, but rather extend the values.

    Args:
        existing_job: The currently scheduled job.
        new_job_kwargs: New `kwargs` for the scheduled job which should extend the
            given `kwargs`.

    Returns:
        The merged job `kwargs`.
    """
    merged_job_modification = existing_job.kwargs or {}
    for key, updated in new_job_kwargs.items():
        merged_job_modification[key] = _merge_single_job_kwarg(
            key, merged_job_modification.get(key), updated
        )

    return merged_job_modification


def _merge_single_job_kwarg(
    key: Text,
    current: Union[bool, Dict, Set, List, None],
    updated: Union[bool, Dict, Set, List, None],
) -> Union[bool, Dict, Set, List, None]:
    """Merge the value of a single `kwarg` with an updated value.

    `kwargs` are the arguments which are passed as argument to the scheduled function
    which the `BackgroundScheduler` executes. Re-scheduling an existing job should not
    overwrite these values, but rather extend the values.

    Args:
        current: The current value of a `kwarg`.
        updated: An updated value for a `kwarg`.

    Returns:
        Merged value for the `kwarg` as far as merging is implemented for type. Return
        `None` in case merging is not implemented for this type of value.
    """
    if current is None:
        return updated

    if updated is None:
        return current

    if isinstance(current, Set) and isinstance(updated, Set):
        return current | updated
    elif isinstance(current, list) and isinstance(updated, list):
        return current + updated
    elif isinstance(current, dict) and isinstance(updated, dict):
        return {**current, **updated}
    elif isinstance(current, bool) and isinstance(updated, bool):
        return updated
    else:
        logger.warning(
            f"Tried to update job kwargs '{key}' with a value of type "
            f"'{type(updated)}' while the current type is "
            f"'{type(current)}'."
        )
        return current


def run_job_immediately(job_id: Text, **kwargs: Union[bool, Text]) -> None:
    """Trigger a scheduled background job to run immediately.

    Args:
        job_id: ID of the job which should be triggered.
        kwargs: Keyword arguments to call scheduled job function with

    """

    modify_job(job_id, run_immediately=True, **kwargs)


def modify_job(job_id: Text, **kwargs: Union[bool, Text, Dict, Set]) -> None:
    """Modify a scheduled background job.

    Args:
        job_id: ID of the job which should be modified.
        kwargs: Keyword arguments to call scheduled job function with
    """
    job_information = kwargs
    job_information[JOB_ID_KEY] = job_id
    if _job_queue:
        _job_queue.put(job_information)
    else:
        logger.warning(
            f"Can't modify background job '{job_id}' as job queue was not "
            f"initialized."
        )


def reschedule_job(job_id: Text, new_schedule: Text) -> None:
    """Modify a scheduled background job.

    Args:
        job_id: ID of the job which should be modified.
        new_schedule: The updated schedule in crontab format.
    """
    _job_queue.put({JOB_ID_KEY: job_id, JOB_SCHEDULE_KEY: new_schedule})


def start_background_scheduler() -> "Process":
    """Start a background scheduler which runs periodic tasks."""

    # Start scheduler in a separate process so that we can create a process and
    # process-safe interface by using a `Queue` to communicate with it.

    if get_jobs_queue() is None:
        set_jobs_queue(common_utils.mp_context().Queue())
    return common_utils.run_in_process(fn=_run_scheduler)


def cancel_job(job_id: Text) -> None:
    """Cancel any scheduled jobs with the given ID.

    Args:
        job_id: ID of the job which should be canceled.
    """
    _job_queue.put({JOB_ID_KEY: job_id, CANCEL_JOB_KEY: True})
