import json
import logging
from typing import Text

import rasax.community.config
import rasax.community.utils.yaml
import rasax.community.utils.common
from rasax.community.caches.cache_factory import CacheFactory
from sqlalchemy.orm import Query

logger = logging.getLogger(__name__)


class CachedQuery:
    """Stores cached results of SQL queries."""

    CACHE_TIMEOUT_IN_SECONDS = 300  # 5 minutes
    ACCEPTABLE_QUERY_COUNT_NUMBER = 50000  # No problems counting 50K records

    def __init__(self) -> None:
        """Constructs a `CachedQuery` object."""
        config = rasax.community.utils.yaml.extract_partial_endpoint_config(
            rasax.community.config.endpoints_path, "cache"
        )

        if config and "acceptable_query_count_number" in config.keys():
            self.acceptable_query_count_number = int(
                config.get("acceptable_query_count_number", 0)
            )
        else:
            self.acceptable_query_count_number = (
                CachedQuery.ACCEPTABLE_QUERY_COUNT_NUMBER
            )

        self.query_cache = CacheFactory.from_endpoint_config(config, "cached_query")
        logger.debug(f"Rasa X will use {type(self.query_cache)} for caching queries.")

    def count(self, query: Query) -> int:
        """Get query's current `count` number based on a few parameters.

        Detailed description:
        - Text of the query is used as a unique key for caching.
        - If the key doesn't exist, then execute the query again.
        - If the latest number of conversations was less than
            ACCEPTABLE_CONVERSATIONS_NUMBER, then execute the query again.
        - Otherwise return the cached number of last `count()`.

        Args:
            query: SQLAlchemy query that will be used to retrieve the `count()` from.

        Returns:
            Cached or actual result of SQL `count()`.
        """
        query_text = query.statement.compile().string
        query_hash = self._get_key(query_text)
        query_count = self.query_cache.get(query_hash)

        if query_count is not None:
            query_count = json.loads(query_count)
            logger.debug(
                f"Cache hit for SQL query: {query_text}; "
                f"Current cache value: {query_count}"
            )
            return query_count

        # Cache miss, also possible the the key has expired
        query_count = query.count()
        logger.debug(
            f"Cache miss, executed SQL query: {query_text}; "
            f"Query result: {query_count}"
        )

        if query_count >= self.acceptable_query_count_number:
            self.query_cache.set(
                query_hash,
                json.dumps(query_count),
                CachedQuery.CACHE_TIMEOUT_IN_SECONDS,
            )

        return query_count

    @staticmethod
    def _get_key(query_text: Text) -> Text:
        return rasax.community.utils.common.get_text_hash(query_text)
