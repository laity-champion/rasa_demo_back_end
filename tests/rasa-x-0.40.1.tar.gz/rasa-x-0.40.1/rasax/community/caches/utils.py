from sanic import Sanic
from sanic.request import Request
from rasax.community.caches.cached_query import CachedQuery


async def setup_cached_query(app: Sanic) -> None:
    """Creates a cached query object.

    This CachedQuery is created once and available to all incoming requests.

    Args:
        app: The Sanic app.
    """
    app.cached_query = CachedQuery()
    app.register_middleware(set_cached_query, "request")


async def set_cached_query(request: Request) -> None:
    """Add a cached query to the `Request` object.

    Args:
        request: An incoming HTTP request.
    """
    request.ctx.cached_query = request.app.cached_query
