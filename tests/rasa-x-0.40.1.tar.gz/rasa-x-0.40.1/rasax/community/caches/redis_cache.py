from typing import Text, Any, Optional

from rasax.community.caches.cache import Cache
import logging
import redis

DEFAULT_SOCKET_TIMEOUT_IN_SECONDS = 10
DEFAULT_REDIS_CACHE_KEY_PREFIX = "rasax_cache"
DEFAULT_REDIS_CACHE_COMPONENT_PREFIX = "no_component"

logger = logging.getLogger(__name__)


class RedisCache(Cache):
    """Redis-based key-value cache."""

    def __init__(
        self,
        url: Text = "localhost",
        port: int = 6379,
        db: int = 2,
        password: Optional[Text] = None,
        use_ssl: bool = False,
        key_prefix: Optional[Text] = DEFAULT_REDIS_CACHE_KEY_PREFIX,
        component_prefix: Text = DEFAULT_REDIS_CACHE_COMPONENT_PREFIX,
        socket_timeout: float = DEFAULT_SOCKET_TIMEOUT_IN_SECONDS,
    ) -> None:
        """Constructs a redis cache.

        Args:
            url: The url of the redis server.
            port: The port of the redis server.
            db: The name of the database within Redis which should be used by Rasa X.
            password: The password which should be used for authentication with the
                Redis database.
            use_ssl: `True` if SSL should be used for the connection to Redis.
            key_prefix: prefix to prepend to all keys used by the cache. Must be
                alphanumeric.
            component_prefix: prefix to prepend to all keys used by the cache.
                Must be alphanumeric. This prefix will be added after `key_prefix`.
            socket_timeout: Timeout in seconds after which an exception will be raised
                in case Redis doesn't respond within `socket_timeout` seconds.
        """
        self.redis_client = self._connect_to_redis(
            url, port, db, password, use_ssl, socket_timeout
        )

        try:
            self.redis_client.ping()
        except redis.exceptions.ConnectionError as e:
            logger.error(f"Connection error while initializing RedisCache, error: {e}")

        if not key_prefix:
            key_prefix = DEFAULT_REDIS_CACHE_KEY_PREFIX

        self._key_prefix = f"{key_prefix}:{component_prefix}"

    def _connect_to_redis(
        self,
        url: Text,
        port: int,
        db: int,
        password: Optional[Text],
        use_ssl: bool,
        socket_timeout: float,
    ) -> redis.Redis:
        return redis.Redis(
            host=url,
            port=int(port),
            db=int(db),
            password=password,
            ssl=use_ssl,
            socket_timeout=socket_timeout,
        )

    def get_key_prefix(self) -> Text:
        """Returns the key prefix that the cache is using."""
        return self._key_prefix

    def _construct_key(self, key) -> Text:
        return f"{self.get_key_prefix()}:{key}"

    def get(self, key: Text) -> Optional[Any]:
        """Returns a value associated with `key`.

        Args:
            key: value of the key.

        Returns:
            Actual value associated with `key`, or `None`.
        """
        try:
            result = self.redis_client.get(self._construct_key(key))
            if result is not None:
                return result
        except redis.exceptions.ConnectionError as e:
            logger.error(
                f"Connectior error while reading from redis, key: {key}, error: {e}"
            )

        return None

    def set(self, key: Text, value: Text, expire_time: Optional[int] = None) -> None:
        """Sets the value at `key` to `value` inside the cache.

        Args:
            key: value of the key.
            value: value that will be set at `key`.
            expire_time: expire time of the `key`, in seconds.
        """
        try:
            self.redis_client.set(self._construct_key(key), value, ex=expire_time)
        except redis.exceptions.ConnectionError as e:
            logger.error(
                f"Connectior error while writing to redis, "
                f"key: {key}, value: {value}, error: {e}"
            )
