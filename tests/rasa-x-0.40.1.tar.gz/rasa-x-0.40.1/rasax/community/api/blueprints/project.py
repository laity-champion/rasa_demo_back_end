import logging
from typing import Any, Dict, Text

import rasax.community.config as rasa_x_config
import rasax.community.constants as constants
import rasax.community.jwt
import rasax.community.services.db_migration_service as db_migration_service
import rasax.community.utils.common as common_utils
import rasax.community.utils.yaml as yaml_utils
import rasax.community.version
import rasax.community.utils.io as io_utils
from rasax.community.api.decorators import (
    inject_rasa_x_user,
    rasa_x_scoped,
    validate_schema,
)
from rasax.community.services import config_service
from rasax.community.services.domain_service import DomainService
from rasax.community.services.feature_service import FeatureService
from rasax.community.services.settings_service import SettingsService, ProjectException
from rasax.community.services.stack_service import StackService, RASA_VERSION_KEY
from rasax.community.services.user_service import (
    UserException,
    UserService,
    MismatchedPasswordsException,
)
from sanic import Blueprint, response
from sanic.request import Request
from sanic.response import HTTPResponse

DELETE_CREATED_CONVERSATIONS_QUERY_PARAMETER = "deleteCreatedConversations"

logger = logging.getLogger(__name__)


async def collect_stack_results(
    stack_services: Dict[Text, StackService]
) -> Dict[Text, Any]:
    """Creates status result dictionary for stack services."""
    from rasax.community.services import stack_service

    stack_result = dict()

    version_responses = await stack_service.collect_version_calls(stack_services)
    for name, _status in version_responses.items():
        if isinstance(_status, dict) and RASA_VERSION_KEY in _status:
            _result = _status.copy()
            _result["status"] = 200
        else:
            _result = {"status": 500, "message": _status}
        stack_result[name] = _result

    return stack_result


def _rasa_services(request: Request) -> Dict[Text, StackService]:
    settings_service = SettingsService.from_request(request)
    return settings_service.stack_services()


def _domain_service(request: Request) -> DomainService:
    return DomainService.from_request(request)


def _user_service(request: Request) -> UserService:
    return UserService.from_request(request)


def blueprint() -> Blueprint:
    """Declare endpoints for all project related actions.

    Returns:
        Sanic Blueprint with project endpoints.
    """
    project_endpoints = Blueprint("project_endpoints")

    @project_endpoints.route("/health", methods=["GET", "HEAD"])
    async def health(request: Request) -> HTTPResponse:
        stack_result = {}

        if hasattr(request.app, "session_maker"):
            stack_services = _rasa_services(request)
            stack_result = await collect_stack_results(stack_services)

        stack_result[
            "database_migration"
        ] = await db_migration_service.migration_status()

        return response.json(stack_result)

    @project_endpoints.route("/version", methods=["GET", "HEAD"])
    async def version(request: Request) -> HTTPResponse:
        rasa_services = _rasa_services(request)

        rasa_versions = {
            environment: await rasa_service.rasa_version()
            for environment, rasa_service in rasa_services.items()
        }
        result = {
            "rasa": rasa_versions,
            "rasa-x": rasax.community.__version__,
            "enterprise": common_utils.is_enterprise_installed(),
        }

        update_version = await common_utils.check_for_updates()
        if update_version:
            result["updates"] = {
                "rasa-x": {
                    "version": update_version,
                    "changelog_url": constants.RASA_X_CHANGELOG,
                }
            }

        rasax.community.jwt.add_jwt_key_to_result(result)
        return response.json(result)

    @project_endpoints.route("/user", methods=["GET", "HEAD"])
    @rasa_x_scoped("user.get")
    @inject_rasa_x_user()
    async def profile(request: Request, user: Dict) -> HTTPResponse:
        user_service = UserService.from_request(request)
        return response.json(
            user_service.fetch_user(user[constants.USERNAME_KEY], return_api_token=True)
        )

    @project_endpoints.route("/user", methods=["PATCH"])
    @rasa_x_scoped("user.update")
    @inject_rasa_x_user()
    @validate_schema("username")
    async def update_username(request: Request, user: Dict) -> HTTPResponse:
        rjs = request.json

        try:
            user_service = UserService.from_request(request)
            user_profile = user_service.update_saml_username(
                user["saml_id"], rjs[constants.USERNAME_KEY]
            )

        except UserException as e:
            return common_utils.error(
                404,
                "UserException",
                "Could not assign username {} to name_id {}"
                "".format(rjs[constants.USERNAME_KEY], user["name_id"]),
                details=e,
            )

        return response.json(user_profile)

    @project_endpoints.route("/users", methods=["GET", "HEAD"])
    @rasa_x_scoped("users.list")
    async def list_users(request: Request) -> HTTPResponse:
        user_service = UserService.from_request(request)
        username_query = common_utils.default_arg(request, constants.USERNAME_KEY, None)
        role_query = common_utils.default_arg(request, "role", None)
        users = user_service.fetch_all_users(
            rasa_x_config.team_name, username_query, role_query
        )
        if not users:
            return common_utils.error(404, "NoUsersFound", "No users found")

        profiles = [user_service.fetch_user(u[constants.USERNAME_KEY]) for u in users]

        return response.json(profiles, headers={"X-Total-Count": len(profiles)})

    @project_endpoints.route("/users/<username:string>", methods=["PUT"])
    @rasa_x_scoped("user.values.update")
    @inject_rasa_x_user()
    @validate_schema("user_update")
    async def update_user(
        request: Request, username: Text, user: Dict[Text, Any]
    ) -> HTTPResponse:
        """Update properties of a `User`."""

        if username != user[constants.USERNAME_KEY]:
            return common_utils.error(
                403, "UserUpdateError", "Users can only update their own propeties."
            )

        try:
            _user_service(request).update_user(
                user[constants.USERNAME_KEY], request.json
            )
            return response.text("", 204)
        except UserException as e:
            return common_utils.error(404, "UserUpdateError", details=e)

    @project_endpoints.route("/users/<username>", methods=["DELETE"])
    @rasa_x_scoped("users.delete")
    @inject_rasa_x_user()
    async def delete_user(request: Request, username: Text, user: Dict) -> HTTPResponse:
        user_service = UserService.from_request(request)
        delete_created_conversations = common_utils.bool_arg(
            request, DELETE_CREATED_CONVERSATIONS_QUERY_PARAMETER, False
        )

        try:
            deleted = user_service.delete_user(
                username,
                requesting_user=user[constants.USERNAME_KEY],
                delete_created_conversations=delete_created_conversations,
            )
            return response.json(deleted)
        except UserException as e:
            return common_utils.error(404, "UserDeletionError", str(e))

    @project_endpoints.route("/user/password", methods=["POST"])
    @rasa_x_scoped("user.password.update")
    @validate_schema("change_password")
    async def change_password(request: Request) -> HTTPResponse:
        rjs = request.json
        user_service = UserService.from_request(request)

        try:
            user = user_service.change_password(rjs)
            if user is None:
                return common_utils.error(404, "UserNotFound", "user not found")
            return response.json(user)
        except MismatchedPasswordsException:
            return common_utils.error(403, "WrongPassword", "wrong password")

    @project_endpoints.route("/projects/<project_id>", methods=["POST"])
    @rasa_x_scoped("projects.create")
    @inject_rasa_x_user()
    async def create_project(
        request: Request, project_id: Text, user: Dict
    ) -> HTTPResponse:
        settings_service = SettingsService.from_request(request)

        try:
            project = settings_service.init_project(user["team"], project_id)
        except ProjectException as e:
            return common_utils.error(404, "ProjectCreationError", details=e)

        user_service = UserService.from_request(request)
        user_service.assign_project_to_user(user, project_id)

        return response.json(project)

    # no authentication because features may be needed
    # before a user is authenticated
    @project_endpoints.route("/features", methods=["GET", "HEAD"])
    async def features(request: Request) -> HTTPResponse:
        feature_service = FeatureService.from_request(request)
        return response.json(feature_service.features())

    @project_endpoints.route("/features", methods=["POST"])
    @rasa_x_scoped("features.update", allow_api_token=True)
    @validate_schema("feature")
    async def set_feature(request: Request) -> HTTPResponse:
        rjs = request.json
        feature_service = FeatureService.from_request(request)
        feature_service.set_feature(rjs)
        return response.json(rjs)

    @project_endpoints.route("/logs")
    @rasa_x_scoped("logs.list", allow_api_token=True)
    async def logs(_request: Request) -> HTTPResponse:
        archive = io_utils.create_temporary_archive("/logs", prefix="log")
        return await response.file(archive)

    @project_endpoints.route("/environments", methods=["GET", "HEAD"])
    @rasa_x_scoped("environments.list", allow_api_token=True)
    async def get_environment_config(request: Request) -> HTTPResponse:
        settings_service = SettingsService.from_request(request)
        environments = settings_service.get_environments_config(
            rasa_x_config.project_name
        )

        if not environments:
            return common_utils.error(
                400,
                "EnvironmentSettingsNotFound",
                "could not find environment settings",
            )

        return response.json(
            {"environments": yaml_utils.dump_yaml(environments.get("environments"))}
        )

    @project_endpoints.route("/chatToken", methods=["GET", "HEAD"])
    @rasa_x_scoped("chatToken.get", allow_rasa_x_token=True)
    async def get_chat_token(request: Request) -> HTTPResponse:
        domain_service = _domain_service(request)
        return response.json(domain_service.get_token())

    @project_endpoints.route("/chatToken", methods=["PUT"])
    @rasa_x_scoped("chatToken.update", allow_api_token=True)
    @validate_schema("update_token")
    async def update_chat_token(request: Request) -> HTTPResponse:
        domain_service = _domain_service(request)
        domain_service.update_token_from_dict(request.json)
        return response.json(domain_service.get_token())

    @project_endpoints.route("/projects/<project_id>/actions", methods=["GET", "HEAD"])
    @rasa_x_scoped("actions.get")
    async def get_domain_actions(request: Request, project_id: Text) -> HTTPResponse:
        domain_actions = DomainService.from_request(request).get_actions_from_domain(
            project_id
        )

        if domain_actions is None:
            return common_utils.error(400, "DomainNotFound", "Could not find domain.")

        # convert to list for json serialisation
        domain_actions = list(domain_actions)

        return response.json(
            domain_actions, headers={"X-Total-Count": len(domain_actions)}
        )

    @project_endpoints.route("/projects/<project_id>/actions", methods=["POST"])
    @rasa_x_scoped("actions.create")
    @validate_schema("action")
    @inject_rasa_x_user()
    async def create_new_action(
        request: Request, project_id: Text, user: Dict[Text, Any]
    ) -> HTTPResponse:
        domain_service = DomainService.from_request(request)
        try:
            created = domain_service.add_new_action(
                request.json, project_id, user[constants.USERNAME_KEY]
            )
            return response.json(created, status=201)
        except ValueError as e:
            return common_utils.error(
                400, "ActionCreationError", "Action already exists.", details=e
            )

    @project_endpoints.route(
        "/projects/<project_id>/actions/<action_id:int>", methods=["PUT"]
    )
    @rasa_x_scoped("actions.update")
    @validate_schema("action")
    async def update_action(
        request: Request, action_id, project_id: Text
    ) -> HTTPResponse:
        domain_service = DomainService.from_request(request)
        try:
            updated = domain_service.update_action(action_id, request.json)
            return response.json(updated)
        except ValueError as e:
            return common_utils.error(
                404,
                "ActionNotFound",
                f"Action with id '{action_id}' was not found.",
                details=e,
            )

    @project_endpoints.route(
        "/projects/<project_id>/actions/<action_id:int>", methods=["DELETE"]
    )
    @rasa_x_scoped("actions.delete")
    async def delete_action(
        request: Request, action_id: int, project_id: Text
    ) -> HTTPResponse:
        domain_service = DomainService.from_request(request)
        try:
            domain_service.delete_action(action_id)
            return response.text("", 204)
        except ValueError as e:
            return common_utils.error(
                404,
                "ActionNotFound",
                f"Action with id '{action_id}' was not found.",
                details=e,
            )

    @project_endpoints.route("/config", methods=["GET", "HEAD"])
    @rasa_x_scoped("config.get", allow_rasa_x_token=True)
    async def get_runtime_config(_: Request) -> HTTPResponse:
        config_dict, errors = config_service.get_runtime_config_and_errors(
            rasa_x_config.credentials_path, rasa_x_config.endpoints_path
        )

        if errors:
            return common_utils.error(
                400,
                "FileNotFoundError",
                common_utils.add_plural_suffix(
                    "Could not find runtime config file{}.", errors
                ),
                details=errors,
            )

        return response.json(config_dict)

    return project_endpoints
