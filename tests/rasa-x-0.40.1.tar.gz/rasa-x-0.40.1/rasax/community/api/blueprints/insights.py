from rasax.community import telemetry
from sanic import Blueprint, response
from sanic.request import Request
import http

from rasax.community.database.insights import ReportStatus
from rasax.community.services import websocket_service
import rasax.community.utils.common
from rasax.community.api.decorators import (
    rasa_x_scoped,
    validate_schema,
)
import rasax.community.config
import rasax.community.utils.common
from rasax.community.services.insights.insight_service import (
    InsightService,
    InsightCalculationInProgressException,
    NLUInsightReportAlreadyFinishedException,
    RasaEvaluationResultsNotAvailable,
)


def blueprint() -> Blueprint:
    """Declare endpoints for NLU intent insights.

    Returns:
        Blueprint with endpoints for intent insights.
    """
    insights_endpoints = Blueprint("insight_endpoints")

    @insights_endpoints.route("/insights/nlu", methods=["POST"])
    @rasa_x_scoped("insights.nlu.create")
    async def create_nlu_insight_report(request: Request) -> response.HTTPResponse:
        """Creates a new NLU insight report and starts the evaluation process.

        If running in local mode, the evaluation will try to be read from file
        and the insights report will be created immediately.
        If running in server mode, a request will be sent to the Rasa API to start the
        evaluation. Once the results are returned via a callback, the report will be
        created.


        Args:
            request: The incoming request.

        Returns:
            Response that contains a created (but not yet finished) insight report.
        """
        insight_service = InsightService.from_request(request)
        try:
            nlu_insight_report = await insight_service.start_nlu_insight_report_process(
                rasax.community.config.rasa_x_token
            )
            return response.json(nlu_insight_report, http.HTTPStatus.CREATED)
        except InsightCalculationInProgressException as e:
            return rasax.community.utils.common.error(
                http.HTTPStatus.ACCEPTED, "NLUInsightCalculationInProgress", details=e,
            )

    @insights_endpoints.route("/insights/nlu", methods=["HEAD", "GET"])
    @rasa_x_scoped("insights.nlu.list")
    async def get_nlu_insight_reports(request: Request) -> response.HTTPResponse:
        """Gets the intent reports.

        Args:
            request: The incoming request.

        Returns:
            Response that contains a matching intent insights reports without
            the detailed insights.
        """
        limit = rasax.community.utils.common.int_arg(request, "limit")
        offset = rasax.community.utils.common.int_arg(request, "offset", 0)
        sort_order = rasax.community.utils.common.enum_arg(
            request, "sort_order", {"asc", "desc"}, "asc"
        )
        status = rasax.community.utils.common.enum_object_from_arg(
            request, "status", ReportStatus
        )
        insight_service = InsightService.from_request(request)
        reports, count = insight_service.get_nlu_insight_reports(
            limit=limit, offset=offset, sort_order=sort_order, report_status=status
        )

        return response.json(reports, headers={"X-Total-Count": count})

    @insights_endpoints.route(
        "/insights/nlu/<insight_report_id:int>/evaluation", methods=["POST"]
    )
    @rasa_x_scoped("insights.nlu.update", allow_rasa_x_token=True)
    @validate_schema("nlu_evaluation")
    async def update_nlu_insight_report_evaluation(
        request: Request, insight_report_id: int,
    ) -> response.HTTPResponse:
        """Updates insight report with the evaluation.

        Usually called by Rasa Open Source once it's finished with the
        cross-validation or if an error occurred during the cross-validation.

        Args:
            request: Request that contains a cross-validation result or
                an error payload in case something went wrong.
            insight_report_id: ID of the insight report to update.

        Returns:
            Response that contains an updated insight report without the detailed insights.
        """
        insight_service = InsightService.from_request(request)

        try:
            updated_insight = insight_service.finish_nlu_insight_report(
                insight_report_id, request.json
            )
            websocket_service.send_message(
                websocket_service.Message(
                    websocket_service.MessageTopic.INSIGHTS, "evaluation_done"
                )
            )
            return response.json(updated_insight, http.HTTPStatus.OK)
        except ValueError as e:
            return rasax.community.utils.common.error(
                http.HTTPStatus.NOT_FOUND,
                "NLUInsightReportNotFound",
                f"Could not find requested insight report with ID {insight_report_id}.",
                details=e,
            )

        except KeyError as e:
            return rasax.community.utils.common.error(
                http.HTTPStatus.BAD_REQUEST,
                "InvalidNLUInsightData",
                "Could not update the specified NLUInsightReport.",
                details=e,
            )
        except NLUInsightReportAlreadyFinishedException as e:
            return rasax.community.utils.common.error(
                http.HTTPStatus.BAD_REQUEST,
                "NLUInsightCalculationCannotBeUpdated",
                f"Cannot update the insight report with ID {insight_report_id} "
                f"because it is already completed.",
                details=e,
            )

    @insights_endpoints.route(
        "/insights/nlu/<insight_report_id:int>/evaluation", methods=["HEAD", "GET"]
    )
    @rasa_x_scoped("models.evaluations.get")
    async def get_rasa_open_source_evaluation_result(
        request: Request, insight_report_id: int,
    ) -> response.HTTPResponse:
        """Gets the Rasa Open Source evaluation results.

        Args:
            request: The incoming request.
            insight_report_id: ID of the insight report which the evaluation result
                belongs to.

        Returns:
            HTTP response.
        """
        insight_service = InsightService.from_request(request)

        try:
            evaluation = insight_service.get_rasa_open_source_evaluation_result_for_report(
                insight_report_id
            )
            telemetry.track(telemetry.CROSS_VALIDATION_RESULT_REQUESTED)

            return response.json(evaluation)
        except ValueError as e:
            return rasax.community.utils.common.error(
                http.HTTPStatus.NOT_FOUND,
                "NLUInsightReportNotFound",
                f"Could not find requested insight report with ID {insight_report_id}.",
                details=e,
            )
        except RasaEvaluationResultsNotAvailable as e:
            return rasax.community.utils.common.error(
                http.HTTPStatus.ACCEPTED, "NLUInsightCalculationInProgress", details=e,
            )

    @insights_endpoints.route(
        "/insights/nlu/<insight_report_id:int>", methods=["HEAD", "GET"]
    )
    @rasa_x_scoped("insights.nlu.get")
    async def get_nlu_insight_report(
        request: Request, insight_report_id: int
    ) -> response.HTTPResponse:
        """Gets the full NLU insight report by ID.

        Query, limit, offset and sort_by all apply to the intents in the report.

        Args:
            request: The incoming request.

        Returns:
            Response that contains an intent insight report including
            the details of the calculated insights.
        """
        text_query = rasax.community.utils.common.default_arg(request, "q", None)
        limit = rasax.community.utils.common.int_arg(request, "limit")
        offset = rasax.community.utils.common.int_arg(request, "offset", 0)
        sort_by = rasax.community.utils.common.enum_arg(
            request,
            "sort_by",
            {
                "intent_name",
                "f1_score",
                "precision",
                "recall",
                "number_of_training_examples",
            },
            "recall",
        )
        sort_order = rasax.community.utils.common.enum_arg(
            request, "sort_order", {"asc", "desc"}, "asc"
        )
        insight_service = InsightService.from_request(request)

        nlu_insight_report, count = insight_service.get_nlu_insight_report_full_by_id(
            insight_report_id=insight_report_id,
            project_id=rasax.community.config.project_name,
            text_query=text_query,
            limit=limit,
            offset=offset,
            sort_by=sort_by,
            sort_order=sort_order,
        )

        if nlu_insight_report:
            return response.json(nlu_insight_report, headers={"X-Total-Count": count})
        else:
            return rasax.community.utils.common.error(
                http.HTTPStatus.NOT_FOUND,
                "NLUInsightReportNotFound",
                "Could not find the last NLU insight.",
            )

    @insights_endpoints.route("/insights/config", methods=["HEAD", "GET"])
    @rasa_x_scoped("insights.config.get")
    async def get_config(request: Request) -> response.HTTPResponse:
        """Gets the intent insight config.

        Args:
            request: The incoming request.

        Returns:
            Response that contains the config.
        """
        insight_service = InsightService.from_request(request)

        config = insight_service.get_config()
        return response.json(config)

    @insights_endpoints.route("/insights/config", methods=["PUT"])
    @rasa_x_scoped("insights.config.update")
    @validate_schema("intent_insight_config")
    async def update_config(request: Request) -> response.HTTPResponse:
        """Updates the intent insight config.

        Args:
            request: The incoming request.

        Returns:
            Response that contains the updated configuration.
        """
        insight_service = InsightService.from_request(request)

        new_config = request.json
        try:
            insight_service.update_config(new_config)
            return response.json(new_config)
        except ValueError as e:
            return rasax.community.utils.common.error(
                http.HTTPStatus.BAD_REQUEST, "ConfigUpdateFailed", details=e,
            )

    return insights_endpoints
