import itertools
import json
import logging
import time
from typing import Text, List, Dict, Any, Optional, Tuple, Set, NamedTuple

from sqlalchemy import or_, and_

import rasax.community.constants as constants
import rasax.community.config as rasa_x_config
import rasax.community.utils.common as common_utils
import rasax.community.utils.cli as cli_utils
from sanic.request import Request
from sqlalchemy.orm import Query
from sqlalchemy.sql.elements import BinaryExpression

from rasa.shared.constants import UTTER_PREFIX
from rasax.community.database.data import Response
from rasax.community.database.service import DbService

logger = logging.getLogger(__name__)


def _fix_response_name_key(response: Dict[Text, Any]) -> None:
    if "template" in response:
        response[constants.RESPONSE_NAME_KEY] = response.pop("template")
        cli_utils.raise_warning(
            f"The response you provided includes the key 'template'. This key has been "
            f"deprecated and renamed to '{constants.RESPONSE_NAME_KEY}'. The 'template' key will "
            f"no longer work in future versions of Rasa X. Please use "
            f"'{constants.RESPONSE_NAME_KEY}' instead.",
            FutureWarning,
        )


class HashedResponse(NamedTuple):
    response_content: Text
    content_hash: Text


def _get_hashed_response(response: Dict[Text, Any]) -> HashedResponse:
    response_content = json.dumps(response, sort_keys=True)
    content_hash = common_utils.get_text_hash(response_content)

    return HashedResponse(response_content=response_content, content_hash=content_hash)


class NlgService(DbService):
    def save_response(
        self,
        response: Dict[Text, Any],
        username: Optional[Text] = None,
        domain_id: Optional[int] = None,
        project_id: Text = rasa_x_config.project_name,
        filename: Optional[Text] = None,
    ) -> Dict[Text, Any]:
        """Save response.

        Args:
            response: Response object to save.
            username: Username performing the save operation.
            domain_id: Domain associated with the response.
            project_id: Project ID associated with the response.
            filename: If present, indicates that the response was read from (or
                should be written into) a training data file, rather than the domain.

        Raises:
            ValueError: When any of the following conditions is true:
                1. No domain ID is specified (if `filename` is `None`)
                2. The response name does not start with
                   `rasa.shared.constants.UTTER_PREFIX`
                3. A response with the same text already exists

        Returns:
            The saved response object.
        """
        response = response.copy()

        if (domain_id is None) == (filename is None):
            raise ValueError("Exactly one of domain ID or filename must be specified.")

        _fix_response_name_key(response)

        response_name = Response.get_stripped_value(
            response, constants.RESPONSE_NAME_KEY
        )

        if not response_name or not response_name.startswith(UTTER_PREFIX):
            raise AttributeError(
                f"Failed to save response. Response '{response_name}' does "
                f"not begin with '{UTTER_PREFIX}' prefix."
            )

        response[constants.RESPONSE_NAME_KEY] = response_name
        response["text"] = Response.get_stripped_value(response, "text")

        if self.get_response(project_id, response):
            raise ValueError(
                f"Another response with same pair of ({constants.RESPONSE_NAME_KEY}, text) "
                f"(({response_name},{response['text']})) already exists for this "
                f"project and domain."
            )

        if not username:
            username = rasa_x_config.default_username

        hashed_response = _get_hashed_response(response)

        new_response = Response(
            response_name=response[constants.RESPONSE_NAME_KEY],
            text=response["text"],
            content=hashed_response.response_content,
            annotated_at=time.time(),
            annotator_id=username,
            project_id=project_id,
            hash=hashed_response.content_hash,
            filename=filename,
        )

        if domain_id is not None:
            new_response.domain_id = domain_id

        self.add(new_response)

        # flush so ID becomes available
        self.flush()

        return new_response.as_dict()

    def _build_responses_query(
        self,
        columns: List[Text],
        response_query: Optional[Text],
        precise_response_query_search: bool,
        text_query: Optional[Text],
        intersect_filters: bool,
    ) -> Query:
        query = self.query(*common_utils.get_query_selectors(Response, columns))
        response_query_expression = self._build_response_query_expression(
            response_query, precise_response_query_search,
        )
        text_query_expression = self._build_text_query_expression(text_query)
        if response_query and text_query and not intersect_filters:
            query = query.filter(or_(response_query_expression, text_query_expression))
        else:
            if response_query:
                query = query.filter(response_query_expression)
            if text_query:
                query = query.filter(text_query_expression)
        return query

    @staticmethod
    def _build_text_query_expression(
        text_query: Optional[Text],
    ) -> Optional[BinaryExpression]:
        if text_query:
            return Response.text.ilike(f"%{text_query}%")
        return None

    @staticmethod
    def _build_response_query_expression(
        response_query: Optional[Text], precise_response_query_search: bool
    ) -> Optional[BinaryExpression]:
        if response_query:
            if precise_response_query_search:
                responses_to_query = response_query.split(",")
                return Response.response_name.in_(responses_to_query)
            else:
                return Response.response_name.ilike(f"%{response_query}%")
        return None

    def fetch_responses(
        self,
        text_query: Optional[Text] = None,
        response_query: Optional[Text] = None,
        fields_query: Optional[List[Tuple[Text, bool]]] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
        sort_by_response_name: bool = False,
        intersect_filters: bool = False,
        precise_response_query_search: bool = True,
    ) -> common_utils.QueryResult:
        """Returns a list of responses.

        Each response includes its response name as a property under RESPONSE_NAME.

        An example of a response item could be:
        ```
        {
            "text": "Hey! How are you?",
            RESPONSE_NAME: "utter_greet",
            "id": 6,
            "annotator_id": "me",
            "annotated_at": 1567780833.8198001,
            "project_id": "default",
            "edited_since_last_training": false
        }
        ```

        Args:
            text_query: Filter results by response text (case insensitive).
            response_query: Filter results by response name.
                It may be either a string of comma-separated values or
                a pattern in case `precise_response_query_search` is set to `False`.
            fields_query: Fields to include per item returned.
            limit: Maximum number of responses to be retrieved.
            offset: Excludes the first ``offset`` responses from the result.
            sort_by_response_name: If ``True``, sort responses by their
                `RESPONSE_NAME` property.
            intersect_filters: If `True`, join `text_query` and
                `response_query` conditions with an AND. Use `OR` otherwise.
            precise_response_query_search: If `False`, search for
                `response_query` using `LIKE` operator.

        Returns:
            List of responses with total number of responses found.
        """
        columns = common_utils.get_columns_from_fields(fields_query)

        query = self._build_responses_query(
            columns=columns,
            response_query=response_query,
            precise_response_query_search=precise_response_query_search,
            text_query=text_query,
            intersect_filters=intersect_filters,
        )

        if sort_by_response_name:
            query = query.order_by(Response.response_name.asc())

        total_number_of_results = query.count()
        responses = query.offset(offset).limit(limit).all()

        if columns:
            results = [
                common_utils.query_result_to_dict(r, fields_query) for r in responses
            ]
        else:
            results = [t.as_dict() for t in responses]

        return common_utils.QueryResult(results, total_number_of_results)

    def get_grouped_responses(
        self,
        text_query: Optional[Text] = None,
        response_query: Optional[Text] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
        intersect_filters: bool = True,
        precise_response_query_search: bool = True,
    ) -> common_utils.QueryResult:
        """Return responses grouped by their response name.

        Args:
            text_query: Filter responses by response text (case insensitive).
            response_query: Filter response groups by response name.
            limit: Maximum number of response groups to be retrieved.
            offset: Excludes the first ``offset`` response groups from the result.
            intersect_filters: If `True`, join `text_query` and
                `response_query` conditions with an `AND`. Use `OR` otherwise.
            precise_response_query_search: If `False`, search for
                `response_query` using `LIKE` operator.

        Returns:
            `QueryResult` containing grouped responses and total number of responses
            across all groups.
        """
        group_query = self._build_responses_query(
            columns=["response_name"],
            response_query=response_query,
            precise_response_query_search=precise_response_query_search,
            text_query=text_query,
            intersect_filters=intersect_filters,
        )
        group_query = group_query.group_by(Response.response_name)
        group_query = group_query.offset(offset).limit(limit).subquery()

        response_query_part = self._build_responses_query(
            columns=[],
            response_query=response_query,
            precise_response_query_search=precise_response_query_search,
            text_query=text_query,
            intersect_filters=intersect_filters,
        )

        full_query = response_query_part.join(
            group_query, Response.response_name == group_query.c.response_name
        )
        full_query = full_query.order_by(Response.response_name.asc())

        total_number_of_results = full_query.count()
        responses = full_query.all()
        results = [t.as_dict() for t in responses]

        grouped_responses = itertools.groupby(
            results, key=lambda each: each[constants.RESPONSE_NAME_KEY]
        )

        result = [
            {constants.RESPONSE_NAME_KEY: k, "responses": list(g)}
            for k, g in grouped_responses
        ]

        return common_utils.QueryResult(result, total_number_of_results)

    def fetch_all_response_names(self) -> Set[Text]:
        """Fetch a list of all response names in db."""
        return {t[constants.RESPONSE_NAME_KEY] for t in self.fetch_responses()[0]}

    def delete_response(self, _id: int) -> bool:
        """Delete a response given its ID.

        Args:
            _id: Responses's ID.

        Returns:
            `True` if a response was found and deleted, `False` otherwise.
        """
        result = self.query(Response).filter(Response.id == _id).first()
        if result:
            self.delete(result)
            return True

        return False

    def delete_all_responses(self, in_training_data: bool = False) -> None:
        """Bulk delete all responses.

        Args:
            in_training_data: If `True`, delete only responses that were
                specified inside a training data file (not in the domain).
                Currently, only Response Selector responses can be specified
                this way.
        """
        query = self.query(Response)

        if in_training_data:
            query = query.filter(Response.domain_id.is_(None))

        query.delete()

    def update_response(
        self, _id: int, response: Dict[Text, Any], username: Text
    ) -> Response:
        """Update the contents of an existing response.

        Args:
            _id: ID of response to update.
            response: New contents of the reponse.
            username: User modifying the response.

        Raises:
            KeyError: If the response was not found.
            AttributeError: If response name does not start with the correct prefix.
            ValueError: If the response (name, text) tuple is not unique.

        Returns:
            Updated response.
        """
        response = response.copy()

        old_response = self.query(Response).filter(Response.id == _id).first()
        if not old_response:
            raise KeyError(f"Could not find existing response with ID '{_id}'.")

        _fix_response_name_key(response)

        response_name = Response.get_stripped_value(
            response, constants.RESPONSE_NAME_KEY
        )

        if not response_name or not response_name.startswith(UTTER_PREFIX):
            raise AttributeError(
                f"Failed to update response. Response '{response_name}' does "
                f"not begin with '{UTTER_PREFIX}' prefix."
            )

        response[constants.RESPONSE_NAME_KEY] = response_name
        response["text"] = Response.get_stripped_value(response, "text")

        if self.get_response(old_response.project_id, response):
            raise ValueError(
                f"Response could not be saved since another one with same pair of "
                f"({constants.RESPONSE_NAME_KEY}, text) exists."
            )

        hashed_response = _get_hashed_response(response)

        old_response.response_name = response[constants.RESPONSE_NAME_KEY]
        old_response.text = response["text"]
        old_response.annotated_at = time.time()
        old_response.content = hashed_response.response_content
        old_response.annotator_id = username
        old_response.edited_since_last_training = True
        old_response.hash = hashed_response.content_hash

        # because it's the same as the updated response
        return old_response

    def replace_responses(
        self,
        new_responses: List[Dict[Text, Any]],
        username: Optional[Text] = None,
        domain_id: Optional[int] = None,
    ) -> int:
        """Deletes all responses and adds new responses.

        Returns the number of inserted responses.
        """
        self.delete_all_responses()
        insertions = 0
        for response in new_responses:
            try:
                inserted = self.save_response(response, username, domain_id=domain_id)
                if inserted:
                    insertions += 1
            except ValueError:
                pass

        return insertions

    def get_training_data_responses(
        self, project_id: Text, filename: Optional[Text] = None
    ) -> Dict[Text, Any]:
        """Return responses that were specified in training data files.

        Args:
            project_id: Project ID.
            filename: Filename to filter responses by, if present.

        Returns:
            Dictionary containing responses, as they would be structured in the
            domain or in a training data file.
        """
        from rasax.community.database.domain import dump_responses

        responses = self.query(Response).filter(
            Response.project_id == project_id, Response.domain_id.is_(None)
        )

        if filename:
            responses = responses.filter(Response.filename == filename)

        return dump_responses(responses.all())

    def get_response(
        self, project_id: Text, response: Dict[Text, Any]
    ) -> Optional[Response]:
        """Return a response that has the specified `project_id` and `response`.

        Args:
            project_id: Project ID.
            response: Response.
        """
        _fix_response_name_key(response)

        return (
            self.query(Response)
            .filter(
                and_(
                    Response.project_id == project_id,
                    Response.hash == _get_hashed_response(response).content_hash,
                )
            )
            .first()
        )

    def mark_responses_as_used(
        self, training_start_time: float, project_id: Text = rasa_x_config.project_name
    ) -> None:
        """Unset the `edited_since_last_training_flag` for responses which were included
        in the last training.

        Args:
            training_start_time: annotation time until responses should be marked as
                used in training.
            project_id: Project which was trained.

        """
        responses_which_were_used_in_training = (
            self.query(Response)
            .filter(
                and_(
                    Response.annotated_at <= training_start_time,
                    Response.edited_since_last_training,
                    Response.project_id == project_id,
                )
            )
            .all()
        )
        for response in responses_which_were_used_in_training:
            response.edited_since_last_training = False

    def rename_responses(
        self, old_response_name: Text, response: Dict[Text, Text], annotator: Text
    ) -> None:
        """
        Bulk-rename all responses with this response name.

        Args:
            old_response_name: The name of the response which should be renamed.
            response: The object containing the new response values.
            annotator: The name of the user who is doing the rename.
        """
        responses = (
            self.query(Response)
            .filter(Response.response_name == old_response_name)
            .all()
        )
        new_response_name = response["name"]
        for response in responses:
            content = json.loads(response.content)
            content[constants.RESPONSE_NAME_KEY] = new_response_name
            hashed_response = _get_hashed_response(content)

            response.response_name = new_response_name
            response.annotated_at = time.time()
            response.annotator_id = annotator
            response.content = hashed_response.response_content
            response.hash = hashed_response.content_hash

    @staticmethod
    def from_request(request: Request, **kwargs) -> "NlgService":
        """Creates a `NlgService` from an incoming HTTP request's DB session.

        Args:
            request: Incoming HTTP request.
            **kwargs: other key-value args, not used.

        Returns:
            `NlgService` instance with a connection to the DB.
        """
        return NlgService(request.ctx.db_session)
