"""Add all new tables for NLU intent insights.

Reason:
The new feature called "Intent insights" requires us to create several
new tables to store all the data.

Revision ID: 524fbfe6bac0
Revises: 895af7dcae07

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
from rasax.community.database.insights import ReportStatus

revision = "524fbfe6bac0"
down_revision = "895af7dcae07"
branch_labels = None
depends_on = None


def upgrade():
    """Adds the tables."""
    op.create_table(
        "nlu_insight_report",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("started_at", sa.DateTime(), nullable=False),
        sa.Column("finished_at", sa.DateTime(), nullable=True),
        sa.Column("evaluation_payload", sa.Text(), nullable=True),
        sa.Column(
            "status",
            sa.Enum(ReportStatus),
            nullable=False,
            default=ReportStatus.IN_PROGRESS,
        ),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_table(
        "intent_evaluation_result",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("nlu_insight_report_id", sa.Integer(), nullable=False),
        sa.Column("intent_name", sa.String(255), nullable=False, index=True),
        sa.Column("f1_score", sa.Float(), nullable=False, index=True),
        sa.Column("precision", sa.Float(), nullable=False, index=True),
        sa.Column("recall", sa.Float(), nullable=False, index=True),
        sa.ForeignKeyConstraint(["nlu_insight_report_id"], ["nlu_insight_report.id"]),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_table(
        "intent_insight",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("intent_evaluation_result_id", sa.Integer(), nullable=False),
        sa.Column("source", sa.String(255), nullable=False),
        sa.Column("details", sa.Text(), nullable=False),
        sa.ForeignKeyConstraint(
            ["intent_evaluation_result_id"], ["intent_evaluation_result.id"]
        ),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_table(
        "intent_insight_configuration",
        sa.Column("id", sa.Integer, primary_key=True, nullable=False),
        sa.Column("schedule", sa.String(999), nullable=True),
        sa.Column("cross_validation_folds", sa.Integer(), nullable=False),
        sa.Column("calculator_configuration", sa.Text, nullable=False),
    )


def downgrade():
    """Drops the tables."""
    op.drop_table("nlu_insight_report")
    op.drop_table("intent_evaluation_result")
    op.drop_table("intent_insight")
    op.drop_table("intent_insight_configuration")
