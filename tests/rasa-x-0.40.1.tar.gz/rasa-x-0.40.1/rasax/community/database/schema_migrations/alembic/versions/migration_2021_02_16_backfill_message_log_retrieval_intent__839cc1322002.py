"""Backfill message_log retrieval intent names.

Reason:
We now expand retrieval intent names when storing
NLU inbox items (`message_log` table), this migration
backfills this data based off of the linked conversation
event.

Revision ID: 839cc1322002
Revises: e2b7e06f6dc5

"""
from alembic import op
from typing import Text
import json
import sqlalchemy as sa
import rasax.community.database.schema_migrations.alembic.utils as migration_utils


# revision identifiers, used by Alembic.
revision = "839cc1322002"
down_revision = "e2b7e06f6dc5"
branch_labels = None
depends_on = None

TABLE_MESSAGE_LOG = "message_log"
BULK_SIZE = 500


def upgrade():
    """Load the correctly expanded intent name of the log and the all the intent rankings from the `conversation_event` table."""
    bind = op.get_bind()
    session = sa.orm.Session(bind=bind)

    message_log = migration_utils.get_reflected_table(TABLE_MESSAGE_LOG, session)
    conversation_event = migration_utils.get_reflected_table(
        "conversation_event", session
    )

    query = (
        session.query(
            message_log.c.id,
            message_log.c.intent,
            message_log.c.intent_ranking,
            conversation_event.c.intent_name.label("conversation_event_intent"),
            conversation_event.c.data.label("conversation_event_data"),
        )
        .join(conversation_event, conversation_event.c.id == message_log.c.event_id)
        .enable_eagerloads(False)
        .yield_per(BULK_SIZE)
    )

    update_stmt = (
        sa.update(message_log)
        .where(message_log.c.id == sa.bindparam("log_id"))
        .values(
            intent=sa.bindparam("intent"), intent_ranking=sa.bindparam("intent_ranking")
        )
    )
    values = []
    for row in query:
        event_data = json.loads(row.conversation_event_data)
        intent_ranking = event_data.get("parse_data", {}).get("intent_ranking")

        intent_changes = row.intent != row.conversation_event_intent
        ranking_changes = json.dumps(intent_ranking) != row.intent_ranking
        if not intent_changes and not ranking_changes:
            continue

        values.append(
            {
                "log_id": row.id,
                "intent": row.conversation_event_intent,
                "intent_ranking": json.dumps(intent_ranking),
            }
        )

        if len(values) >= BULK_SIZE:
            session.execute(update_stmt, values)
            values.clear()

    if values:
        session.execute(update_stmt, values)


def downgrade():
    """Split intent name and intent rankings of log by "/" and take the first result."""

    def condense_intent(intent: Text) -> Text:
        if intent is None:
            return intent

        parts = intent.split("/")
        if parts[0] == "":
            return intent

        return parts[0]

    bind = op.get_bind()
    session = sa.orm.Session(bind=bind)

    message_log = migration_utils.get_reflected_table(TABLE_MESSAGE_LOG, session)

    update_stmt = (
        sa.update(message_log)
        .where(message_log.c.id == sa.bindparam("log_id"))
        .values(
            intent=sa.bindparam("intent"), intent_ranking=sa.bindparam("intent_ranking")
        )
    )
    values = []

    for log in session.query(message_log).yield_per(BULK_SIZE):
        intent = condense_intent(log.intent)

        intent_ranking = json.loads(log.intent_ranking) or []
        for prediction in intent_ranking:
            prediction["name"] = condense_intent(prediction["name"])

        intent_changes = log.intent != intent
        ranking_changes = json.dumps(intent_ranking) != log.intent_ranking

        if not intent_changes and not ranking_changes:
            continue

        values.append(
            {
                "log_id": log.id,
                "intent": intent,
                "intent_ranking": json.dumps(intent_ranking),
            }
        )

        if len(values) >= BULK_SIZE:
            session.execute(update_stmt, values)
            values.clear()

    if values:
        session.execute(update_stmt, values)
