"""Add message_log_entity_metadata table.

Reason:
We need to store entity data more structured to be able to query
`message_log` records by entity.

Revision ID: e2b7e06f6dc5
Revises: d5fa2187f905

"""
from alembic import op
import json
import rasax.community.database.schema_migrations.alembic.utils as migration_utils
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = "e2b7e06f6dc5"
down_revision = "d5fa2187f905"
branch_labels = None
depends_on = None


TABLE_NAME = "message_log_entity_metadata"
COLUMN_MESSAGE_LOG_ID = "message_log_id"
COLUMN_ENTITY = "entity"
BULK_SIZE = 500


def _create_table():
    op.create_table(
        TABLE_NAME,
        sa.Column(COLUMN_MESSAGE_LOG_ID, sa.Integer(), nullable=False),
        sa.Column(COLUMN_ENTITY, sa.String(255), nullable=False),
        sa.ForeignKeyConstraint(
            [COLUMN_MESSAGE_LOG_ID], ["message_log.id"], ondelete="cascade"
        ),
        sa.PrimaryKeyConstraint(COLUMN_MESSAGE_LOG_ID, COLUMN_ENTITY),
    )


def _backfill_entity_metadata():
    bind = op.get_bind()
    session = sa.orm.Session(bind=bind)

    message_log_table = migration_utils.get_reflected_table("message_log", session)
    entity_metadata_table = migration_utils.get_reflected_table(TABLE_NAME, session)

    entity_metadata_to_save = []
    for log in (
        session.query(message_log_table).filter_by(archived=False).yield_per(BULK_SIZE)
    ):
        try:
            entities = json.loads(log.entities)
        except json.JSONDecodeError:
            continue

        if not entities:
            continue

        entity_names = [e.get("entity") for e in entities]
        unique_names = set([e for e in entity_names if e is not None])

        for name in unique_names:
            entity_metadata_to_save.append(
                {COLUMN_MESSAGE_LOG_ID: log.id, COLUMN_ENTITY: name}
            )

        # periodically bulk insert entity_metadata rows
        if len(entity_metadata_to_save) >= BULK_SIZE:
            op.bulk_insert(entity_metadata_table, entity_metadata_to_save)
            entity_metadata_to_save.clear()

    # insert the remaining entity_metadata rows that are less than BULK_SIZE
    op.bulk_insert(entity_metadata_table, entity_metadata_to_save)


def upgrade():
    """Adds the new table."""
    _create_table()
    _backfill_entity_metadata()


def downgrade():
    """Drops the new table."""
    op.drop_table(TABLE_NAME)
