"""Add filename column to response.

Reason:
Since responses can potentially been read from a training data file
('responses' section), we need a way to distinguish between those
and responses read from the domain. For this, this column is added
to track the training data filename a response can belong to (similar to
how we store filename for `TrainingData` as well).

Revision ID: 47396643a5b4
Revises: 43a803b8c1fd

"""
import sqlalchemy as sa

import rasax.community.database.schema_migrations.alembic.utils as migration_utils


# revision identifiers, used by Alembic.
revision = "47396643a5b4"
down_revision = "e4ed14831f48"
branch_labels = None
depends_on = None


RESPONSE_TABLE = "response"
FILENAME_COLUMN = "filename"


def upgrade():
    """Perform upgrade of the DB schema."""
    if migration_utils.get_column(RESPONSE_TABLE, FILENAME_COLUMN) is None:
        migration_utils.create_column(
            RESPONSE_TABLE, sa.Column(FILENAME_COLUMN, sa.String(255), nullable=True)
        )


def downgrade():
    """Perform downgrade of the DB schema."""
    if migration_utils.get_column(RESPONSE_TABLE, FILENAME_COLUMN) is not None:
        migration_utils.drop_column(RESPONSE_TABLE, FILENAME_COLUMN)
