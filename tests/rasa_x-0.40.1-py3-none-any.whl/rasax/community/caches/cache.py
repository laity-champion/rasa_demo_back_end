from typing import Any, Optional, Text
from abc import ABC, abstractmethod


class Cache(ABC):
    """Abstract key-value cache."""

    @abstractmethod
    def get(self, key: Text) -> Optional[Any]:
        """Returns a value associated with `key`.

        Args:
            key: value of the key.

        Returns:
            Actual value associated with `key`, or `None`.
        """
        raise NotImplementedError

    @abstractmethod
    def set(self, key: Text, value: Text, expire_time: Optional[int] = None) -> None:
        """Sets the value at `key` to `value` inside the cache.

        Args:
            key: value of the key.
            value: value that will be set at `key`.
            expire_time: expire time of the `key`, in seconds.
        """
        raise NotImplementedError
